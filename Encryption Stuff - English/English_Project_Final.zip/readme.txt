Hello, if you are reading this, then you are looking at decrypting my file. 

Before doing anything, you need to ensure that you install python.
Go here: https://www.python.org/downloads/

Python is a programming language, I have used it to encrypt the file, and the relevant decryption file is there as well. 
If you do not wish to install it, I have included a copy of the decrypted file, but the work is paired best with the decryption file, so see me.
I can show you what the file is like on my computer.

Now, if you have installed python, simply run the Decrypter.py file by double clicking on it.

If you do not wish to, I have included a copy of the file in the folder called extra stuff.

If the pdf stuff is not rendering properly, I have included a few files that have the fonts I used to create the cyphers. 
Simply double click on them and install them, if the pdf is not displaying properly.